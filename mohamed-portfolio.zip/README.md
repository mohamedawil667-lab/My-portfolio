# Mohamed Portfolio – GitHub Pages

1. Fur zip-ka. Waa inuu ku jiraa `index.html` (magaca sidaas oo kale, xarfo yaryar) iyo galka `assets/`.
2. GitHub -> New repository -> magac (tusaale `portfolio`) -> Public.
3. Add file -> Upload files -> soo rar `index.html`, `404.html`, `.nojekyll` iyo galka `assets`. Haddii ay ka badan yihiin 100 fayl, ku soo rar laba jeer (marka hore faylasha waaweyn, kadibna `assets/img`). Ha rarin zip-ka laftiisa.
4. Settings -> Pages -> Source: Deploy from a branch -> Branch: `main` / `(root)` -> Save.
5. Sug 1-2 daqiiqo. Link-gu waa `https://USERNAME.github.io/REPO/`.

Sababaha caadiga ah ee 404: faylka oo aan lagu magacaabin `index.html`; `index.html` oo galka gudihiisa ku jira (waa inuu root ahaado); Pages oo aan la shidin; `Assets` vs `assets` (xarfaha waaweyn/yaryar); zip-ka oo la rarey.
